<?php
include 'config.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            header("Location: report.php");
            exit;
        }
    }
    $error = "Identitas atau Kunci Pengaman Salah!";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Lost & Found - Case File Opening</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .split-screen {
            display: flex;
            min-height: 100vh;
        }
        .hero-side {
            flex: 1;
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.8)), url('https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80') center/cover;
            padding: 60px;
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
        }
        .login-side {
            width: 450px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px;
            background-color: var(--bg-dark);
        }
    </style>
</head>
<body>
    <div class="split-screen">
        <div class="hero-side">
            <h1 style="font-family: 'Playfair Display', serif; font-size: 48px;">Lost & Found</h1>
            <p style="color: #AAA; max-width: 450px; margin-top: 15px; line-height: 1.6;">
                Laporkan barang hilangmu, temukan kembali. Setiap barang yang tertinggal adalah sebuah kasus yang menanti untuk dipecahkan.
            </p>
        </div>
        <div class="login-side">
            <div class="detective-card" style="width: 100%;">
                <div class="stamp">RESTRICTED</div>
                <h3 style="margin-bottom: 25px; font-size: 16px;">[ CASE FILE OPENING ]</h3>
                
                <?php if (isset($error)) echo "<p style='color:red; font-size:12px;'>$error</p>"; ?>

                <form method="POST">
                    <div class="form-group">
                        <label>IDENTITAS AGENT (EMAIL)</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>KUNCI PENGAMAN (PASSWORD)</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" name="login" class="btn-case">MASUK DEPARTEMEN</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>