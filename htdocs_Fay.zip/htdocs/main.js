document.addEventListener("DOMContentLoaded", function() {
    const uploadBox = document.querySelector('.upload-box');
    const fileInput = document.getElementById('photoInput');

    if (uploadBox && fileInput) {
        uploadBox.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadBox.style.background = '#D5D2CC';
        });

        uploadBox.addEventListener('dragleave', () => {
            uploadBox.style.background = '#E5E2DC';
        });

        uploadBox.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadBox.style.background = '#E5E2DC';
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                uploadBox.innerHTML = "📁 " + e.dataTransfer.files[0].name;
            }
        });

        fileInput.addEventListener('change', () => {
            if (fileInput.files.length) {
                uploadBox.innerHTML = "📁 " + fileInput.files[0].name;
            }
        });
    }
});