<?php
include 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

if (isset($_POST['submit_report'])) {
    $user_id   = $_SESSION['user_id'];
    $item_name = $_POST['item_name'];
    $category  = $_POST['category'];
    $desc      = $_POST['description'];
    $date      = $_POST['date'];
    $location  = $_POST['location'];

    // Handle Upload Foto
    $photo = "";
    if (!empty($_FILES['photo']['name'])) {
        $photo = time() . '_' . $_FILES['photo']['name'];
        move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/' . $photo);
    }

    $stmt = $conn->prepare("INSERT INTO reports (user_id, item_name, category, description, incident_date, location, photo) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $user_id, $item_name, $category, $desc, $date, $location, $photo);
    
    if ($stmt->execute()) {
        $success = "Laporan kasus berhasil dibuat!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Lapor Barang Hilang</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🔍 LOST & FOUND</div>
        <nav class="nav-links">
            <a href="report.php" class="active">[ 01. LAPOR HILANG ]</a>
            <a href="bulletins.php">[ 02. BULLETINS ]</a>
            <a href="my_cases.php">[ 03. BERKAS SAYA ]</a>
        </nav>
        <div class="user-badge"><?= $_SESSION['username']; ?></div>
    </header>

    <div class="container">
        <div class="detective-card">
            <div class="stamp">PENDING CASE</div>
            <p style="font-size: 11px; color: var(--accent-red); font-weight: bold;">FORM_EVIDENCE // NO. 0001</p>
            <h2 class="title-large">Lapor Barang Hilang</h2>

            <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>

            <form method="POST" enctype="multipart/form-data">
                <div style="display: flex; gap: 20px;">
                    <div class="form-group" style="flex: 1;">
                        <label>1. NAMA IDENTITAS BARANG</label>
                        <input type="text" name="item_name" class="form-control" required>
                    </div>
                    <div class="form-group" style="flex: 1;">
                        <label>2. KLASIFIKASI KATEGORI</label>
                        <select name="category" class="form-control" required>
                            <option value="">Pilih Klasifikasi</option>
                            <option value="Elektronik">Elektronik</option>
                            <option value="Buku">Buku</option>
                            <option value="Pakaian">Pakaian</option>
                            <option value="Aksesoris">Aksesoris</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label>3. CIRI-CIRI KHUSUS (PETUNJUK)</label>
                    <textarea name="description" class="form-control" rows="4" placeholder="Deskripsikan warna khusus, stiker yang menempel, merk, dll..." required></textarea>
                </div>

                <div style="display: flex; gap: 20px;">
                    <div class="form-group" style="flex: 1;">
                        <label>4. ESTIMASI TANGGAL HILANG</label>
                        <input type="date" name="date" class="form-control" required>
                    </div>
                    <div class="form-group" style="flex: 1;">
                        <label>5. TITIK TERAKHIR TERLIHAT</label>
                        <input type="text" name="location" class="form-control" placeholder="Pilih Lokasi Wilayah Sekolah/Kampus" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>6. UNGGAH FOTO DOKUMENTASI BARANG (OPSIONAL)</label>
                    <div class="upload-box" onclick="document.getElementById('photoInput').click();">
                        📷 KLIK ATAU DRAG FOTO DISINI
                        <input type="file" id="photoInput" name="photo" style="display: none;">
                    </div>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 30px;">
                    <span style="font-size: 10px; color: var(--text-muted);">*Data akan disimpan di Berkas Penyelidikan Aktif Agent.</span>
                    <button type="submit" name="submit_report" class="btn-case" style="width: auto;">KIRIM LAPORAN KASUS</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>