<?php
include 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

$id = $_GET['id'];
$case = $conn->query("SELECT * FROM reports WHERE id=$id")->fetch_assoc();

if (isset($_POST['submit_claim'])) {
    $proof = $_POST['proof'];
    $user_id = $_SESSION['user_id'];

    $conn->query("INSERT INTO claims (report_id, user_id, proof_description) VALUES ($id, $user_id, '$proof')");
    $message = "Klaim berhasil dikirim untuk diverifikasi!";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Klaim Kasus</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🔍 LOST & FOUND</div>
        <nav class="nav-links">
            <a href="report.php">[ 01. LAPOR HILANG ]</a>
            <a href="bulletins.php" class="active">[ 02. BULLETINS ]</a>
            <a href="my_cases.php">[ 03. BERKAS SAYA ]</a>
        </nav>
        <div class="user-badge"><?= $_SESSION['username']; ?></div>
    </header>

    <div class="container">
        <div class="detective-card" style="display: flex; gap: 30px;">
            <div class="stamp" style="border-color: green; color: green;">VERIFIED EXHIBIT</div>
            
            <div style="width: 250px; background: #FFF; padding: 10px; text-align: center; border: 1px solid #DDD;">
                <div style="font-size: 80px; line-height: 200px; background: #EEE;">?</div>
                <p style="font-size: 11px; font-weight: bold; margin-top: 10px;">EXHIBIT SEC_B // NO. <?= $case['id'] ?></p>
            </div>

            <div style="flex: 1;">
                <p style="font-size: 11px; color: var(--accent-red);">CASE DETECTIVE ID: #00<?= $case['id'] ?></p>
                <h2 class="title-large"><?= $case['item_name'] ?></h2>

                <p style="font-size: 12px; margin-bottom: 5px;"><strong>LOKASI DITEMUKAN:</strong> <?= $case['location'] ?></p>
                <p style="font-size: 12px; margin-bottom: 20px;"><strong>TANGGAL PENEMUAN:</strong> <?= $case['incident_date'] ?></p>

                <?php if (isset($message)) echo "<p style='color:green; font-size:12px;'>$message</p>"; ?>

                <div style="background: #E5E2DC; padding: 20px; border-radius: 4px;">
                    <p style="font-size: 11px; font-weight: bold; margin-bottom: 10px;">APAKAH INI BARANG ANDA? KLAIM KASUS INI</p>
                    <form method="POST">
                        <div class="form-group">
                            <label>DESKRIPSIKAN BUKTI KEPEMILIKAN KHUSUS</label>
                            <textarea name="proof" class="form-control" rows="3" placeholder="Sebutkan serial number, nama bluetooth terdaftar, atau stiker tersembunyi..." required></textarea>
                        </div>
                        <button type="submit" name="submit_claim" class="btn-case">KIRIM KLAIM PENYELIDIKAN</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>