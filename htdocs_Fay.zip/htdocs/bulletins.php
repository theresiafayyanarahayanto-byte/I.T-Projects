<?php
include 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

$reports = $conn->query("SELECT * FROM reports ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Barang Yang Ditemukan</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .grid-bulletins {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 20px;
        }
        .polaroid-card {
            background: #EFECE6;
            padding: 15px;
            border-radius: 2px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.3);
            text-align: center;
        }
        .polaroid-img {
            width: 100%;
            height: 180px;
            background: #DDD;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            margin-bottom: 10px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">🔍 LOST & FOUND</div>
        <nav class="nav-links">
            <a href="report.php">[ 01. LAPOR HILANG ]</a>
            <a href="bulletins.php" class="active">[ 02. BULLETINS ]</a>
            <a href="my_cases.php">[ 03. BERKAS SAYA ]</a>
        </nav>
        <div class="user-badge"><?= $_SESSION['username']; ?></div>
    </header>

    <div class="container">
        <h2 class="title-large" style="color: #FFF;">Barang Yang Ditemukan</h2>
        <p style="color: #888; font-size: 12px; margin-bottom: 20px;">DAFTAR TEMUAN TERBARU DI AREA. COCOKKAN DAN DAPATKAN KEMBALI.</p>

        <div class="grid-bulletins">
            <?php while($row = $reports->fetch_assoc()): ?>
                <div class="polaroid-card">
                    <?php if($row['photo']): ?>
                        <img src="uploads/<?= $row['photo'] ?>" class="polaroid-img">
                    <?php else: ?>
                        <div class="polaroid-img">?</div>
                    <?php endif; ?>
                    <p style="font-size: 11px; font-weight: bold;">[EVIDENCE]</p>
                    <p style="font-size: 10px; color: #666; margin: 5px 0;">LOKASI: <?= $row['location'] ?></p>
                    <p style="font-size: 10px; color: #666; margin-bottom: 10px;">TANGGAL: <?= $row['incident_date'] ?></p>
                    <a href="claim.php?id=<?= $row['id'] ?>" class="btn-case" style="display: block; text-decoration: none; font-size: 12px; padding: 8px;">KLAIM BARANG</a>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>