<?php
include 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

$user_id = $_SESSION['user_id'];
$my_reports = $conn->query("SELECT * FROM reports WHERE user_id=$user_id");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Berkas Saya</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="logo">🔍 LOST & FOUND</div>
        <nav class="nav-links">
            <a href="report.php">[ 01. LAPOR HILANG ]</a>
            <a href="bulletins.php">[ 02. BULLETINS ]</a>
            <a href="my_cases.php" class="active">[ 03. BERKAS SAYA ]</a>
        </nav>
        <div class="user-badge"><?= $_SESSION['username']; ?></div>
    </header>

    <div class="container">
        <p style="font-size: 10px; color: var(--accent-red);">STATION_AGENT_REPORT // ID: 0001</p>
        <h2 class="title-large" style="color:#FFF;">Berkas Kasus Saya</h2>

        <div style="display: flex; flex-direction: column; gap: 15px;">
            <?php while($row = $my_reports->fetch_assoc()): ?>
                <div class="detective-card" style="display: flex; align-items: center; justify-content: space-between; padding: 15px 25px;">
                    <div style="display: flex; align-items: center; gap: 20px;">
                        <div style="width: 50px; height: 50px; background: #FFF; display: flex; align-items: center; justify-content: center; font-weight: bold;">?</div>
                        <div>
                            <p style="font-size: 10px; color: #666;">KASUS #00<?= $row['id'] ?> - <?= strtoupper($row['category']) ?></p>
                            <h3 style="font-family: 'Playfair Display', serif;"><?= $row['item_name'] ?></h3>
                            <p style="font-size: 10px; color: #888;">DILAPORKAN PADA: <?= $row['created_at'] ?></p>
                        </div>
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <span class="stamp" style="position: static; margin: 0;"><?= $row['status'] ?></span>
                        <a href="claim.php?id=<?= $row['id'] ?>" class="btn-case" style="padding: 6px 12px; font-size: 11px; text-decoration: none;">LIHAT DETAIL</a>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>